var number_nav_page = 21;
var present_page = 0;
var arg_record = [];
var number_page = 0;
var defaul_number_results = parseInt($(".gird-img").attr("data-count")) - number_nav_page;
var not_show = id_photo_show;
var number_scroll = 0;
var reset = 0;
if(id_photo_show !="" && slug_category !=""){
    number_scroll = 1;
}
$(document).ready(function() {
    /*---------------------------------------Advertise slider------------------------------------------------------*/
    
    $('.slide-logo').bxSlider({
        auto: true,
        slideWidth: 100,
        minSlides: 2,
        maxSlides: 8,
        slideMargin: 10
    });

    /*---------------------------------------company comment------------------------------------------------------*/
    var id_member = 0;
    var box_this  = null;
    $(".company-content-box .comment-like .comment > img").click(function(){
        if(check_login()!=false){
            id_member = $(this).parents(".company-item").attr("data-id");
            box_this  = $(this).parents(".company-item");
            $('#comment_company').modal();
        }
       
    });
    $(".company-item #post-comment").click(function(){
        $(this).parents(".company-item").find(".company-content-box .comment-like .comment > img").trigger("click");
        return false;
    });
    $("#email").attr( "required",false );
    $("#comment_company #sent_comment").click(function(){
        var text = $(this).parents("#comment_company").find("#messenger").val();
        var box_comment = $(this).parents("#comment_company");
        console.log( text);
        if(text != "" && reset_comment == 0 && check_login()!=false){
            reset_comment = 1;
            $.ajax({
                url: base_url + "comments/add/" + id_member + "/member",
                type: 'POST',
                dataType: "json",
                data: {"text": text},
                success: function(data) {
                    console.log(data);
                    if (data["status"] == "true") {
                        var num_comment = parseInt(box_this.find("#num-comment").text()) + 1;
                        box_this.find("#num-comment").html(num_comment);
                        box_comment.find("#messenger").val("");
                        var logo = base_url+"skins/images/signup.png";
                        if(data["logo"] != ""){logo = base_url+data["logo"];}
                        box_this.find(".company-content-box.expand-height").append('<div class="comment-item"><a href="'+base_url+'/profile/index/'+data["member_id"]+'"><img class="media-object" src ="'+logo+'" width="46" height="46"></a><p><strong>'+data["full_name"]+' | '+data["company"]+'</strong></p><p>'+text+'</p></div>');
                    } else {
                        messenger_box("Error message", "Implementation process fails.");
                    }
                    reset_comment = 0;
                },
                error: function() {
                    messenger_box("Error message", "Implementation process fails.");
                    reset_comment = 0;
                }
            });
        }
       
    });
    /*---------------------------------------!company comment------------------------------------------------------*/
     // apply matchHeight to each item container's items
    $('.row-height').each(function() {
        $(this).find('.inner-height').matchHeight({
            byRow: true,
        });
    });
    setTimeout(function() {
        $("#footer").fadeOut(2500)
    }, 1500);
    $(".forgot_page #form-forgot,.reset_pw #form-forgot").submit(function() {
        var valid_form1 = valid_form($(this), "warning", true);
        console.log(valid_form1);
        if (valid_form1 != true) {
            return false;
        }
    });
    /* singin ajax*/
    $("#form-user.login-form #sign-in").click(function() {
        var check_form = valid_form($("#form-user.login-form"), "warning", true);
        if (check_form == true) {
            var text_mail = $(this).parents(".login-form").find("#email").val();
            var password = $(this).parents(".login-form").find("#password").val();
            var project_id = $(this).parents(".login-form").find("#project_id").val();
            var token = $(this).parents(".login-form").find("#token").val();
            var data = {
                "email": text_mail,
                "password": password,
                "project_id": project_id,
                "token": token
            };
            $.ajax({
                url: base_url + "accounts/signin",
                type: 'POST',
                data: data,
                dataType: "json",
                success: function(data_ajax) {
                    if (data_ajax["success"] == "success") {
                        messenger_box("Message", "Login Successfully.");
                        setTimeout(function() {
                            window.location.href = window.location.href;
                        }, 2100);
                    } else {
                        var messenger = "";
                        var i = 0;
                        $.each(data_ajax["messenger"], function(key, value) {
                            i++;
                            $(".login-form #"+key+"").addClass("warning");
                            messenger += "<p>" + i + ". " + value + "</p>";
                        });
                        messenger_box("Error message", messenger);
                    }
                },
                error: function(data_ajax) {
                    messenger_box("Error message", "Error message");
                }
            });
        }
        return false;
    });
    /* signup ajax*/
    $(".singup-form #upload-avatar-control").click(function() {
        $(this).parents(".singup-form").find("#upload_avatar").trigger("click");
    });
    $("#form-user.singup-form #form-user-input").submit(function(event) {
        var valid_form1 = valid_form($("#form-user.singup-form"), "warning", true);
        if (valid_form1 == true) {
            var company = $(this).parents(".singup-form").find("#company").val();
            var first_name = $(this).parents(".singup-form").find("#first-name").val();
            var last_name = $(this).parents(".singup-form").find("#last-name").val();
            var email = $(this).parents(".singup-form").find("#email").val();
            var password = $(this).parents(".singup-form").find("#password").val();
            var project_id = $(this).parents(".singup-form").find("#project_id").val();
            var token = $(this).parents(".singup-form").find("#token").val();
            var url = (typeof(project_id) == 'undefined' || $.trim(project_id) == '') ? window.location.href : '/designwalls/index/' + project_id;
            $("#header #form-user .loadding").show();
            var messenger = "";
            var i;
            var options = {
                dataType: 'json',
                success: function(responseText, statusText, xhr, $form) {
                    console.log(responseText);
                    messenger = "";
                    if (responseText["success"] == "success") {
                        messenger = "<p>Signup Successfully</p>";
                        if (responseText["messenger"]) {
                            messenger = "<p>1.Signup Successfully</p>";
                            i = 1;
                            $.each(responseText["messenger"], function(key, value) {
                                i++;
                                messenger += "<p>" + i + ". " + value + "</p>";
                            });
                            messenger_box("Message", messenger);
                            setTimeout(function() {
                                window.location.href = url;
                            }, 4000);
                        } else {
                            messenger_box("Message", messenger);
                            setTimeout(function() {
                                window.location.href = url;
                            }, 2100);
                        }
                    } else {
                        i = 0;
                        $.each(responseText["messenger"], function(key, value) {
                            i++;
                            messenger += "<p>" + i + ". " + value + "</p>";
                        });
                        messenger_box("Error message", messenger);
                    }
                    $("#header #form-user .loadding").hide();
                }
            };
            $(this).ajaxSubmit(options);
        };
        return false;
    });
    $.each($(".box-refine .right-box li"), function() {
        if ($(this).find("ul").hasClass("parents") == true) {
            $(this).addClass("li-parents").append('<div class="dropdown-category"><span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span></div>');
        }
    });
    $.each($(".box-refine-search .right-box.category"), function() {
        var li_top = "<li id='0'><a href='#'>" + $(this).find(">p").text() + "</a></li>";
        $(this).find(">ul").prepend(li_top);
    });
    var category_search = all_category.slice(0,(all_category.length-1));
    var res =[];
    if(category_search!=""){
        res = category_search.split(",");
    }   
    
    res = res.sort();
    if(res.length > 0){ 
        $.each(res,function(key,value){
            $.each($(".box-refine-search #"+value+""),function(){  
                var tagname = $(this).prop("tagName"); 
                if(tagname == "INPUT"){
                    $(this).prop( "checked", true );
                } 
                if(tagname =="LI"){
                    $(this).parents(".category").find(">p").remove();
                    var text_li =  "<p id ='"+value+"'>"+$(this).find(">a").text()+"<span class='glyphicon glyphicon-menu-down' aria-hidden='true'></span></p>";
                    $(this).parents(".category").prepend(text_li);
                }
            });
        });
    }
    function split( val ) {
      return val.split( /,\s*/ );
    }
    function extractLast( term ) {
      return split( term ).pop();
    }
    $( "#search-service") .bind( "keydown", function( event ) {
        if ( event.keyCode === $.ui.keyCode.TAB &&
            $( this ).autocomplete( "instance" ).menu.active ) {
            event.preventDefault();
        }
    }).autocomplete({
            minLength: 0,
            source: function( request, response ) {
                var arg_business = request.term.split(",");
                var keyword_business = arg_business[(arg_business.length-1)];
                if(keyword_business !=""){
                    $.ajax({
                        url:base_url + "services/get_business_categories",
                        type:  "post",
                        dataType: "json",
                        data:{"keyword": keyword_business,"business_type":business_type}, 
                        success: function (data)
                        {  
                            response($.ui.autocomplete.filter(data, extractLast(keyword_business)));
                        }
                    });
                }
                
            },
            focus: function() {
             
              return false;
            },
            select: function( event, ui ) {
              var terms = split( this.value );
              terms.pop();
              terms.push( ui.item.value );
              terms.push( "" );
              this.value = terms.join( "," );
              var value_input_business = terms[(terms.length-2)];
              if(value_input_business == "Search all "+business_type+""){
                this.value = value_input_business;
              }else{
                this.value = this.value.replace("Search all "+business_type+",","");
              }
              return false;
        }
    });
    $("#page_service .pagination li > a").click(function(){
        return false;
    });
    $("#page_service .pagination li:not(.disabled,.active) > a").click(function(event){
       event.stopPropagation();
       $(this).parents("#page_service").find("input[name = perpage]").val($(this).text());
       $(this).parents("#page_service").trigger("submit");
       return false;
    });
});
$(document).on("click", ".box-refine .right-box.category", function() {
    if ($(this).find(">ul").hasClass("block") == true) {
        $(this).find(">ul").removeClass("block");
    } else {
        $(".box-refine .right-box.category > ul.block").removeClass("block");
        $(this).find(">ul").addClass("block");
    }
});
$(document).on("click", ".menu-location .checkbox input", function() {
    all_category = "";
    var tagname_parent  = $("#seach-home-photo").prop("tagName");
    $.each($(".right-box.location .menu-location input[type=checkbox]:checked"), function() {
        all_category += $(this).val() + ",";
    });
    $.each($(".right-box.category "), function() {
        var idmother = $(this).attr("id");
        var idpareant_category = $(this).find(" > p").attr("id");
        if (idpareant_category != 0) {
            all_category += idmother + ",";
            $.each($(this).find("li#" + idpareant_category + ""), function() {
                all_category += $(this).attr("id") + ",";
                $.each($(this).parents(".li-parents"), function() {
                    all_category += $(this).attr("id") + ",";
                });
            });
        }
    });
    if(tagname_parent =="DIV"){
        $(".gird-img .cards").html("");
        if (keyword == "" && all_category == "" && slug_category == "") {
            number_scroll = 0;
        } else {
            number_scroll = 1;
        }
        not_show ="";
        present_page = 0;
        before_search();
        get_record_search();
    }else{
        var input_seach = $("#input-seach").val();
        var category_search = all_category.slice(0,(all_category.length-1));
        window.location.href = base_url+"search?keyword="+input_seach+"&all_category="+category_search;
    }
});
$(document).on("click", ".box-refine .right-box.category li", function() { 
    var tagname_parent  = $("#seach-home-photo").prop("tagName");
    all_category = "";
    var text = $(this).find(">a").text() + '<span class="glyphicon glyphicon-menu-down" aria-hidden="true"></span>';
    var id = $(this).attr("id");
    $(this).parents(".category").find("p").attr("id", id).html(text);
    $(".box-refine .right-box.category > ul.block").removeClass("block");
     $.each($(".right-box.location .menu-location input[type=checkbox]:checked"), function() {
        all_category += $(this).val() + ",";
    });
    $.each($(".right-box.category "), function() {
        var idmother = $(this).attr("id");
        var idpareant_category = $(this).find(" > p").attr("id");
        if (idpareant_category != 0) {
            all_category += idmother + ",";
            $.each($(this).find("li#" + idpareant_category + ""), function() {
                all_category += $(this).attr("id") + ",";
                $.each($(this).parents(".li-parents"), function() {
                    all_category += $(this).attr("id") + ",";
                });
            });
        }
    });
    if(tagname_parent =="DIV"){
        $(".gird-img .cards").html("");
        if (keyword == "" && all_category == "" && slug_category == "") {
            number_scroll = 0;
        } else {
            number_scroll = 1;
        }
        not_show ="";
        present_page = 0;
        before_search();
        get_record_search();
    }else{
        var input_seach = $("#input-seach").val();
        var category_search = all_category.slice(0,(all_category.length-1));
        window.location.href = base_url+"search?keyword="+input_seach+"&all_category="+category_search;
    }
    
    return false;
});
$(document).on("click", ".box-refine-search .show-parent", function() {
    $(this).toggleClass("show");
    $(this).parents(".li-parents").find(".parents").toggleClass("block");
    return false;
});
$(document).on("click", ".li-parents .dropdown-category span", function(event) {
    event.stopPropagation();
    $(this).parent().parent().find("> ul.parents").toggleClass("block");
    if ($(this).parent().parent().hasClass("show_parent") != true) {
        $(this).parent().parent().addClass("show_parent");
        $(this).parent().parent().find(" > .dropdown-category").html('<span class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span>');
    } else {
        $(this).parent().parent().removeClass("show_parent");
        $(this).parent().parent().find(" > .dropdown-category").html('<span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>');
    }
});
/*-------------------------------paging seach----------------------------*/
$(document).on("keyup", "#header #seach-home-photo #input-seach", function(event) {
    if (event.keyCode == 13) {
        $(this).parents("#seach-home-photo").find(".seach-sumit").trigger("click");
    }
});
get_page();
$(document).on("click", "#header #seach-home-photo .seach-sumit", function() {
    keyword = $(this).parents("#seach-home-photo").find('#input-seach').val();
    $(".gird-img .loadding").css({
        "bottom": "auto",
        "top": "110px"
    });
    $(".gird-img .cards").html("");
    $("#footer").show();
    setTimeout(function() {
        $("#footer").fadeOut(2500)
    }, 1500);
    all_category = "";
    $.each($(".right-box.location .menu-location input[type=checkbox]:checked"), function() {
        all_category += $(this).val() + ",";
    });
    $.each($(".right-box.category "), function() {
        var idmother = $(this).attr("id");
        var idpareant_category = $(this).find(" > p").attr("id");
        if (idpareant_category != 0) {
            all_category += idmother + ",";
            $.each($(this).find("li#" + idpareant_category + ""), function() {
                all_category += $(this).attr("id") + ",";
                $.each($(this).parents(".li-parents"), function() {
                    all_category += $(this).attr("id") + ",";

                });
            });
        }
    });
    //all_category = all_category.slice(0, (all_category.length - 1));
    $(this).parents("#seach-home-photo").find("#all_category").val(all_category);
    $(".box-refine .box-refine-search.block").removeClass("block");
    if ($(this).parents("#seach-home-photo").hasClass("seach_page_total") == true) {
        not_show = "";
        before_search();
        present_page = 0;
        get_record_search();
        if (keyword == "" && all_category == "" && slug_category == "") {
            number_scroll = 0;
        } else {
            number_scroll = 1;
        }
        return false;
    }
});
$(window).scroll(function() {
    if (($(window).scrollTop() + $(window).height() + 40) >= $(document).height() && (number_page - number_scroll) > present_page && reset == 0) {
        reset = 1;
        $(".gird-img .loadding").css({
            "bottom": "21px",
            "top": "auto"
        });
        before_search();
        if (keyword != "" || all_category != "" || slug_category != "") {
            present_page++;
            get_record_search(false);
        } else {
            get_record_search(false);
            present_page++;
        } 
    }
    if (($(window).scrollTop() + $(window).height() + 40) >= $(document).height()) {
        $("#footer").fadeIn(1000);
    }
    if($(window).width() <=768){
        if($(window).scrollTop() > top_seach.top && top_seach.top !=0){
            $(".seach-home.destop-seach").css("top","0"); 
        }else{
            $(".seach-home.destop-seach").css("top","69px");
        }
    }
    
});
$( window ).resize(function() {
  if($(window).width() > 768){
     $(".seach-home.destop-seach").css("top","0");
  }
});
function before_search() {
    $(".gird-img .loadding").show();
}

function get_record_search(page_get) {
    $.ajax({
        url: base_url + "photos/seachimages",
        type: 'POST',
        dataType: "json",
        data: {
            "keyword": keyword,
            "all_category": all_category,
            "nav": present_page,
            "number_nav_page": number_nav_page,
            "type_photo": type_photo_seach,
            "id_photo_show": not_show,
            "slug_category": slug_category
        },
        success: function(data) {
            console.log(data);
            arg_record = data["photo"];
            if(page_get != false){
                defaul_number_results = data["total_page"];
                if (keyword == "" && all_category == "") {
                    defaul_number_results = defaul_number_results - number_nav_page;
                }
                if (data["id_photo_show"] != "" && keyword == "" && all_category == "") {
                    not_show = data["id_photo_show"];
                }
                if (keyword != "" || all_category != "") {
                    $("#all-img-seach").html(defaul_number_results + " results found " + keyword);
                } else {
                    $("#all-img-seach").html((defaul_number_results + number_nav_page) + " results found " + type_photo_seach);
                }
                get_page();
            }
            if(arg_record != ""){
              $(".gird-img .cards").append(arg_record);
              after_search();
            }
            

        },
    });
}

function get_page() {
    var page = defaul_number_results / number_nav_page;
    page = ("" + page).split(".");
    if (page.length > 1) {
        number_page = parseInt(page[0]) + 1;
    } else {
        number_page = parseInt(page[0]);
    }
}

function after_search() {
    $(".gird-img .loadding").hide();
    $("#footer").show();
    reset = 0;
    setTimeout(function() {
        $("#footer").fadeOut(2500)
    }, 1500);
}

/*-------------------------------!paging seach----------------------------*/
/*-------------------------------like photo----------------------------*/
var reset_like = 0;
$(document).on("click", "#like-photo", function(event) {
    event.stopPropagation();
    if(check_login()!=false){
        var this_total = $(this);
        var photo_id_like = $(this).attr("data-id");
        var object='photo';
        if (typeof $(this).attr('data-object') != 'undefined' && $(this).attr('data-object')!=null) {
            object=$(this).attr('data-object');
        }  
        if (isNaN(photo_id_like) == false && photo_id_like != "" && reset_like == 0) {
            var number_like = parseInt(this_total.parents(".likes").find("#number-like").text());
            reset_like = 1;
            $.ajax({
                url: base_url + "photos/like/"+object,
                type: 'POST',
                dataType: "json",
                data: {
                    "photo_id": photo_id_like
                },
                success: function(data) {
                    console.log(data);
                    if (data["success"] == "success") {
                        var img_like = "";
                        if (data["like"] == 1) {
                            img_like = base_url + "skins/images/yes-like.png";
                        } else {
                            img_like = base_url + "skins/images/no-like.png";
                        }
                        this_total.parents(".likes").find("#number-like").html(number_like + (data["like"]));
                        this_total.find(" > img").attr("src", img_like);
                    }
                    reset_like = 0;
                },
            });
        }
    }
    return false
});
/*-------------------------------!like photo----------------------------*/
$(document).on("click", ".impromation-project .glyphicon-menu-down", function() {
    $(this).parents(".impromation-project").find(".dropdown-impromation-menu").toggleClass("block");
    return false;
});
var photo_id;
var title;
var message;
var object_reporting = "photos";
$(document).on("click", ".impromation-project :not(#services-report) .dropdown-impromation-menu:not(#deziwall) a,#services-report #report-company", function() {
    $("#reporting_modal").find("#messenger").removeClass("warning");
    if (check_login() != false) {
        photo_id = $(this).parents("#wrapper-impormant-image").attr("data-id");
        title = $(this).text();
        if(typeof $(this).attr("data-reporting") != 'undefined' ){
           object_reporting = $(this).attr("data-reporting");
        }
        $('#reporting_modal').modal();
    }
    return false;
});
$(document).on("click", "#reporting_modal #sent-report", function() {
    message = $(this).parents("#reporting_modal").find("#messenger").val();
    if(message.trim()!=""){
        $.ajax({
            url:  base_url+"home/send_mail_flag",
            type: "post",
            data: {
                'id'               : photo_id,
                "message"          : message,
                "title"            : title,
                "object_reporting" : object_reporting
            },
            success: function(data) {
                if (data.trim() == "success") {
                    $('#reporting_modal').modal('hide');
                    messenger_box("Message", "Email sent successfully");
                } else {
                    $('#reporting_modal').modal('hide');
                    messenger_box("Error message", "Implementation process fails");
                }
            },
        });
    }else{
        $(this).parents("#reporting_modal").find("#messenger").addClass("warning");
    }
});
var type_sent_mail = "photo";
var company_name   = "Company name";
$(document).on("click", "#share-image-email", function() {
    photo_id = $(this).parents("#wrapper-impormant-image").attr("data-id");
    var type = $(this).attr("data-reporting");
    if(typeof type != 'undefined'){
        type_sent_mail =  type;
        company_name   =  $(this).attr("data-name");
    }
    $('#sent_image').modal();
    return false;
});
$(document).on("click", "#sendmail", function() {
    var check_form = valid_form($(this).parents("#sent_image"), "warning", true);
    if (check_form == true) {
        var url_site_send = window.location.href;
        var email = $("#sent_image #email").val();
        var subject = $("#sent_image #subject").val();
        var message = $("#sent_image #message").val();
        $.ajax({
            url: base_url + 'home/sendmail',
            type: 'post',
            data: {
                'email': email,
                'subject': subject,
                'photo_id': photo_id,
                'message': message,
                'url': url_site_send,
                'type_sent_mail' : type_sent_mail,
                'company_name': company_name
            },
            success: function(data) {
                console.log(data);
                if (data.trim() == 'success') {
                    $('#sent_image').modal('hide');
                    messenger_box("Message", "Email sent successfully.");

                } else {
                    $('#sent_image').modal('hide');
                    messenger_box("Message", "Email sent unsuccessful.");
                }
            },
            error: function() {
                $('#sent_image').modal('hide');
                messenger_box("Message", "Email sent unsuccessful.");
            }
        });
    }
    return false;
});
/*---------------------------------------Pin to wall-------------------------------------------------------*/
var type_designwall = 0;
var number_project_owner = 0;
$(document).on("click", "#pins-to", function() {
    if (check_login() != false) {
        $("#pin_to_wall .warning").removeClass("warning");
        $("#new-project").val("");
        $("#pin-new-category").val("");
        $("#pin-comment").val("");
        var htmlct = '<option value="0">New Category</option>';
        $("#pin-new-category").css("display", "block");
        $("#pin-category").html(htmlct);
        var html = '<option selected="selected" value ="defaul" disabled="disabled">Your DEZIGNWALLS</option>';
        photo_id = $(this).parents("#wrapper-impormant-image").attr("data-id");
        var url_img = $(this).parents("#wrapper-impormant-image").find(".wrapper-image .item > img").attr("src");
        $("#pin_to_wall #image-pin").attr("src", url_img);
        $.ajax({
            url: base_url + 'photos/get_project_member',
            type: 'post',
            dataType: 'json',
            data: {
                'photo_id': photo_id,
            },
            success: function(data) {
                var user_onew = "";
                if (data["success"] == "success") {
                    type_designwall = data["type_designwall"];
                    number_project_owner = data["number_project_owner"];
                    if (data["reponse"].length > 0) {
                        $.each(data["reponse"], function(key, value) {
                            if (value["member_onew"] != data["user_id"] && (value["first_name"] != "" || value["last_name"] != "")) {
                                user_onew = "(created by " + value["first_name"] + " " + value["last_name"] + ")";
                            }
                            html += "<option class='project-select' value = '" + value['pr_id'] + "'>&nbsp;&nbsp;&nbsp;&nbsp;" + value['project_name'] + " - " + value['created_at'] + " " + user_onew + "</option>";
                            user_onew = "";
                        });

                    }
                    if (type_designwall > number_project_owner) {
                        html += '<option id = "add_new_project" value="0">&nbsp;&nbsp;&nbsp;&nbsp;New DEZIGNWALL</option>';
                    } else {
                        $("#add_new_project").remove();
                    }
                    html += '<option value ="upgrade">Upgrade for More WALLS</option>';

                    $("#pin-project").html(html);
                    $('#pin_to_wall').modal();
                } else {
                    messenger_box("Message", "Implementation process fails.");
                }
            },
            error: function() {
                messenger_box("Message", "Implementation process fails.");
            }
        });
    }
    return false;
});
$(document).on("change", "select#pin-project", function() {
    var project_id = $(this).val();
    var html = '';
    $("#messenger_upgrade").hide();
    $("#new-project").hide();
    if (project_id != "defaul" && project_id != "upgrade" && project_id != null && project_id != 0) {
        $.ajax({
            url: base_url + 'photos/get_project_category',
            type: 'post',
            dataType: 'json',
            data: {
                'project_id': project_id
            },
            success: function(data) {
                if (data["success"] == "success") {
                    if (data["reponse"].length > 0) {
                        $("#pin-new-category").css("display", "none");
                        $.each(data["reponse"], function(key, value) {
                            html += '<option value="' + value["category_id"] + '">' + value["title"] + '</option>';
                        });
                        html += '<option value="0">New Category</option>';
                        $("#pin-category").html(html);
                    } else {
                        $("#pin-new-category").css("display", "block");
                    }
                } else {
                    messenger_box("Message", "Implementation process fails.");
                }
                html = "";
            },
            error: function() {
                messenger_box("Error message", "Implementation process fails.");
            }
        });
    } else {
        if (project_id == "upgrade") {
            $("#messenger_upgrade").show();
        }
        if (project_id == 0) {
            $("#new-project").show();
        }
        html = '<option value="0">New Category</option>';
        $("#pin-new-category").css("display", "block");
        $("#pin-category").html(html);
    }
});
$(document).on("change", "select#pin-category", function() {
    if ($(this).val() == "0") {
        $("#pin-new-category").css("display", "block");
    } else {
        $("#pin-new-category").css("display", "none");
    }
});
$(document).on("click", "#save-dezignwall", function() {
    $("#pin_to_wall .warning").removeClass("warning");
    var pin_project = $("#pin-project").val();
    var pin_category = $("#pin-category").val();
    var new_project = $("#new-project").val();
    var new_category = $("#pin-new-category").val();
    var pin_comment = $("#pin-comment").val();
    if (pin_project == "defaul" || pin_project == "upgrade" || pin_project == null || (pin_category == 0 && new_category == "") || (pin_project == 0 && new_project == "")) {
        if (pin_project == "defaul" || pin_project == "upgrade" || pin_project == null) {
            $("#pin-project").addClass("warning");
            messenger_box("Error message", "Please choose a DESIGNWALL.");
        } else if (pin_category == 0 && new_category == "") {
            $("#pin-new-category").addClass("warning");
            messenger_box("Error message", "Please add title category new.");
        }
        if (pin_project == 0 && new_project == "") {
            $("#new-project").addClass("warning");
            messenger_box("Error message", "Please add title DESIGNWALL new.");
        }
    } else {
        $.ajax({
            url: base_url + "photos/pin_to_wall",
            type: "POST",
            dataType: "json",
            data: {
                "photo_id": photo_id,
                "project_id": pin_project,
                "new_project": new_project,
                "category_id": pin_category,
                "new_category": new_category,
                "pin_comment": pin_comment
            },
            success: function(data) {
                console.log(data);
                if (data["success"] == "success") {
                    var number_pin = parseInt($("#num-pin").text()) + 1;
                    if (pin_comment != "") {
                        $("#num-comment").html(parseInt($("#num-comment").text()) + 1);
                    }
                    $("#num-pin").html(number_pin);
                    $('#pin_to_wall').modal('hide');
                    var content_html = '<div class="return-pins text-center"><a href="' + base_url + 'search" id="return-seach" class="btn btn-gray" name="return-seach">Return to Search</a>';
                    content_html += '<a href="' + base_url + 'designwalls/index/' + data["project_id"] + '" id="return-dezignwall" class="btn btn-primary" name="return-dezignwall">Go to your DEZIGNWALL</a></div>';
                    messenger_box("Successfully saved to DEZIGNWALL!", content_html);
                } else {
                    messenger_box("Error message", data["messenger"]);
                }

            },
            error: function() {
                $('#pin_to_wall').modal('hide');
                messenger_box("Error message", "Implementation process fails.");
            }
        });
    }
});
/*---------------------------------------!Pin to wall-------------------------------------------------------*/
/*---------------------------------------photo comment------------------------------------------------------*/
var reset_comment = 0;
$(document).on("keyup", ".image-page #comment-input", function(event) {
    if (event.keyCode == 13 && $(this).val() != "" && reset_comment == 0) {
        reset_comment = 1;
        if (check_login() != false) {
            var object_id = $(this).parents("#wrapper-impormant-image").attr("data-id");
            var text = $(this).val();
            $.ajax({
                url: base_url + "comments/add/" + object_id + "/photo",
                type: 'POST',
                dataType: "json",
                data: {
                    "text": text
                },
                success: function(data) {
                    if (data["status"] == "true") {
                        $("#num-comment").html(parseInt($("#num-comment").text()) + 1);
                        $(".image-page #comment-input").val("");
                    } else {
                        messenger_box("Error message", "Implementation process fails.");
                    }
                    reset_comment = 0;
                },
                error: function() {
                    messenger_box("Error message", "Implementation process fails.");
                    reset_comment = 0;
                }
            });
        }
    }
});
$(document).on("click", ".gird-img #add-comment", function() {
    var this_new = $(this);
    var photo_comment = this_new.data("id");
    var object='photo';
    if (typeof $(this).attr('data-object') != 'undefined' && $(this).attr('data-object')!=null) {
        object=$(this).attr('data-object');
    }  
    var text = this_new.parents(".card-info").find("#content-comment").val();
    var avatar = base_url+'skins/images/signup.png';
    $(this).parents(".box-input-comment").find("#content-comment").removeClass("warning");
    if(text == ""){$(this).parents(".box-input-comment").find("#content-comment").addClass("warning");}
    if (check_login() != false && text.trim() != "") {
        $.ajax({
            url: base_url + "comments/add/" + photo_comment + "/"+object,
            type: 'POST',
            dataType: "json",
            data: {
                "text": text
            },
            success: function(data) {
                if (data["status"] == "true") {
                    this_new.parents(".card-wrapper").find("#num-comment").html(parseInt(this_new.parents(".card-wrapper").find("#num-comment").text()) + 1);
                    this_new.parents(".card-info").find("#content-comment").val("");
                    if (data["avatar"] != "") {
                        avatar = data["avatar"];
                    }
                    var html = '<div class="row"><div class="col-xs-2 remove-padding"><img src="' + avatar + '" class="left"></div>';
                    html += '<div class="col-xs-10 box-impromation">';
                    html += '<p><strong>' + data["full_name"] + ' | ' + data["company"] + '</strong></p>';
                    html += '<p>' + text + '</p>';
                    html += '</div></div>';
                    this_new.parents(".card-info").find(".uesr-box-impromation .avatar").append(html);
                    this_new.parents(".card-info").find(".uesr-box-impromation").scrollTop(this_new.parents(".card-info").find(".uesr-box-impromation")[0].scrollHeight);
                } else {
                    messenger_box("Error message", "Implementation process fails.");
                }
                reset_comment = 0;
            },
            error: function() {
                messenger_box("Error message", "Implementation process fails.");
                reset_comment = 0;
            }
        });
    }
});
/*---------------------------------------!photo comment------------------------------------------------------*/
$(document).on("click","#hide_about #more-about",function(){
    $(this).parents("#hide_about").hide();
    $(this).parents("#about").find("#show_about").slideDown();
    return false;
});
$(document).on("click","#show_about #more-about",function(){
    $(this).parents("#show_about").slideUp("slow",function(){
        $(this).parents("#about").find("#hide_about").show();
    });
    return false;
});
$(document).on("click",".microsite > p > a",function(){
    if(is_login != 1){
        window.location.href = base_url+"search?action=signin";
        return false;
    }
});
$(document).on("keyup","#seach-home-photo #input-seach",function(event){
    $(this).parents("#seach-home-photo").find(">ul.like_search").remove();
    var new_this_seach = $(this);
    if($(this).val().trim() !=""){
        $.ajax({
            url:base_url+"photos/get_photos_like",
            type:"POST",
            data:{"keyword" : $(this).val().trim()},
            dataType:"json",
            success:function(data){
                var html ="";
                if(data["success"] == "success" && data["record"].length>0){
                    html+="<ul class='like_search'>";
                    $.each(data["record"],function(key,value){
                        html+= '<li>'+value["name"]+'</li>';
                    });
                    html+="</ul>";
                    new_this_seach.parents("#seach-home-photo").append(html);
                }
            }
        });
    }
});
$(document).on("click","#seach-home-photo .like_search li",function(){
   var text_like = $(this).text();
   $(this).parents("#seach-home-photo").find("#input-seach").val(text_like);
   $(this).parents(".like_search").remove();
})